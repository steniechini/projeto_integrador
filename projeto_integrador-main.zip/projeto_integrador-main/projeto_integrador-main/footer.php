<div class="row">
    <div class=" col-12">
        <footer>
            <ul>
                <li><a href="https://twitter.com" target="_blank"><img src="img/logotwitter.webp" alt="logo twitter"></a></li>
                <li><a href="https://facebook.com" target="_blank"><img src="img/logofacebook.webp" alt="logo facebook"></a></li>
                <li><a href="https://instagram.com" target="_blank"><img src="img/logoinstagram.webp" alt="logo instagram"></a></li>
                <li><a class="float-right" href="termos.php ">Termos de uso</a></li>
            </ul>
           
        </footer>
    </div>
</div>